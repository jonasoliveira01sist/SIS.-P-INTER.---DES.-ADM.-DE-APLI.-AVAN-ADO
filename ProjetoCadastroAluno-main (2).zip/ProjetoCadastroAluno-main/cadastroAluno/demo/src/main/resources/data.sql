CREATE TABLE Alunos
(
    id       INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR,
    rg int,
    cpf VARCHAR,
    endereco VARCHAR,
    curso VARCHAR

);

INSERT INTO Alunos (nome, rg,  cpf, endereco, curso) VALUES ('jonas', 1234567, 145236987, 'rua da esperanca', 'internet');
INSERT INTO Alunos (nome, rg,  cpf, endereco, curso) VALUES ('bella', 0001002, 156258798, 'rua das lamentacoes', 'veterinaria');
