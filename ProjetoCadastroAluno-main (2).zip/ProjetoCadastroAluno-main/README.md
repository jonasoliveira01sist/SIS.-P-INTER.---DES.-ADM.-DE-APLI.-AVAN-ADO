# ProjetoCadastroAluno
Cadastro de Aluno

Projeto de desenvolvimento de cadastro de alunos, com CPF, RG, endereço, e curso. Tem cadastro e remoção de aluno, alteração de aluno, pesquisar aluno, por nome e por curso.

banco de dados h2, spring boot 
